import cv2

img = cv2.imread("image/car.jpg")
imgresize=cv2.resize(img,(600,300))
edge_canny=cv2.Canny(imgresize, 150, 180)
cv2.imshow("Human", edge_canny)
cv2.waitKey(0)

# print("Succeed")
