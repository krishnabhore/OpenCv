import cv2
import numpy as np

img = cv2.imread("image/cards.jpg")
# imgresize=cv2.resize(img,(900,1000))

#coordinates of edges of image
imgorg=np.float32([[217,358],[355,350],[218,487],[378,484]])

# #Dots at the edges of image
# for x in range(0,4):
#     cv2.circle(img, (imgorg[x][0],imgorg[x][1]), 5, (255,0,0),-1)
    

width,height=217,300
imgnew=np.float32([[0,0],[width,0],[0,height],[width,height]])

transformedimg=cv2.getPerspectiveTransform(imgorg, imgnew)

perspectiveimg=cv2.warpPerspective(img, transformedimg, (width,height))



cv2.imshow("card1", perspectiveimg)
cv2.waitKey(0)
# width,height=250,350


# cv2.imshow("card", imgresize)


# print("Succeed")
