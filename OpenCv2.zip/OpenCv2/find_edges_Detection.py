import cv2

img = cv2.imread("image/shape.png")
imgresize=cv2.resize(img,(600,400))


#gray image
img_Gray=cv2.cvtColor(imgresize,cv2.COLOR_BGR2GRAY)

#Edge Detection
edge_canny=cv2.Canny(img_Gray, 90, 180)

#identifying Contours
contour,heirarchy=cv2.findContours(edge_canny, cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE )

#draw Contours
# cv2.drawContours(imgresize,contour , -1, (255,0,0))




# Altenative method


def findCnt(imgresize,contour):
    for cnt in contour:
        area=cv2.contourArea(cnt)
        # print(area)
        if area>1:
            cv2.drawContours(imgresize,contour , 4, (255,0,0),2)
            perimeter=cv2.arcLength(cnt, True)
            # print(perimeter)
            approx=cv2.approxPolyDP(cnt, 0.04*perimeter, True)
            sides=len(approx)
            print(sides)
            x,y,w,h=cv2.boundingRect(approx)
            # print(boundry)
            if sides==3:
                textType="Triangle"
            elif  sides==4:
                textType="Square" 
            elif  sides>=5:
                textType="Cicular"

            cv2.rectangle(imgresize, (x,y), (x+w,y+h), (0,0,0),2)
            cv2.putText(imgresize, textType, (x+(w//2)-20,y+(h//2)-20), cv2.FONT_HERSHEY_COMPLEX, 0.5, (255,255,255))






findCnt(imgresize,contour)
cv2.imshow("Human", imgresize) 
cv2.waitKey(0)
    
    


# print("Succeed")
