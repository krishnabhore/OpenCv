import cv2
facecascade=cv2.CascadeClassifier("haarcascades/haarcascade_frontalface_default.xml")
# img = cv2.imread("image/lena.png")
img = cv2.imread("image/hritik.jfif")
imgresize=cv2.resize(img,(600,300))
imgGray = cv2.cvtColor(imgresize,cv2.COLOR_BGR2GRAY)
face=facecascade.detectMultiScale(imgGray,1.1,4)

for (x,y,w,h) in face:  
    cv2.rectangle(imgresize, (x,y), (x+w,y+h), (255,0,0),2)

cv2.imshow("Human", imgresize)
cv2.waitKey(0)

# print("Succeed")
