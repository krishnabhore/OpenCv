import cv2
import numpy as np

def empty(a):   
    pass


#Trackbars

cv2.namedWindow("Taskbar")
cv2.resizeWindow("Taskbar", 640,300)
cv2.createTrackbar("Hue min","Taskbar", 0, 179, empty)
cv2.createTrackbar("Hue max","Taskbar", 179, 179, empty)
cv2.createTrackbar("Sat min","Taskbar", 0, 255, empty)
cv2.createTrackbar("Sat max","Taskbar", 255, 255, empty)
cv2.createTrackbar("Val min","Taskbar", 204, 255, empty)
cv2.createTrackbar("Val max","Taskbar", 255, 255, empty)

while True:
    img = cv2.imread("image/car1.jfif")
    imgresize=cv2.resize(img,(600,360))
    imgHSV=cv2.cvtColor(imgresize, cv2.COLOR_BGR2HSV)
    # join_hr=np.hstack((imgresize,imgHSV))

    #Trackbars values
    h_min=cv2.getTrackbarPos("Hue min", "Taskbar")
    h_max=cv2.getTrackbarPos("Hue max", "Taskbar")
    s_min=cv2.getTrackbarPos("Sat min", "Taskbar")
    s_max=cv2.getTrackbarPos("Sat max", "Taskbar")
    v_min=cv2.getTrackbarPos("Val min", "Taskbar")
    v_max=cv2.getTrackbarPos("Val max", "Taskbar")


    #mask Image
    lower=np.array([h_min,s_min,v_min])
    upper=np.array([h_max,s_max,v_max])
    mask=cv2.inRange(imgHSV, lower, upper)
    imgresult=cv2.bitwise_and(imgresize,imgresize,mask=mask)
    
    print(h_min,h_max,s_min,s_max,v_min,v_max)
    cv2.imshow("car", imgresize)
    cv2.imshow("car1", imgHSV)
    cv2.imshow("mask", mask)
    cv2.imshow("mask1", imgresult)
    cv2.waitKey(1)

# print("Succeed")
