import cv2
Number_plate=cv2.CascadeClassifier("haarcascades/haarcascade_russian_plate_number.xml")
# img = cv2.imread("image/c1.jfif")
img = cv2.imread("image/c2.jfif")
# img = cv2.imread("image/c3.jfif")
imgresize=cv2.resize(img,(600,300))
imgGray = cv2.cvtColor(imgresize,cv2.COLOR_BGR2GRAY)
Nplate=Number_plate.detectMultiScale(imgGray,1.1,4)


for (x,y,w,h) in Nplate:  
    cv2.rectangle(imgresize, (x,y), (x+w,y+h), (255,0,0),2)
plateScan=imgresize[y:y+h,x:x+w]
cv2.imshow("vehicle", imgresize)
cv2.imshow("scan", plateScan)
cv2.waitKey(0)

# print("Succeed")
